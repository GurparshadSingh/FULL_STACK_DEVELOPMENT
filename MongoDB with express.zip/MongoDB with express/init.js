const mongoose = require("mongoose");
const Chat = require("./models/chat.js");

main().then(() => {
    console.log("connection succesfull")
})
    .catch(err => console.log(err));

// let chat1 = new Chat({
//     from: "neha",
//     to: "priya",
//     msg: "send me my pc",
//     created_at: new Date(),
// });
let chats = [
    {
        from: "neha",
        to: "priya",
        msg: "send me my pc",
        created_at: new Date()
    },
    {
        from: "priya",
        to: "neha",
        msg: "I will send it by evening",
        created_at: new Date()
    },
    {
        from: "rahul",
        to: "amit",
        msg: "did you complete the assignment?",
        created_at: new Date()
    },
    {
        from: "amit",
        to: "rahul",
        msg: "yes, sending it now",
        created_at: new Date()
    },
    {
        from: "simran",
        to: "neha",
        msg: "call me when you're free",
        created_at: new Date()
    },
    {
        from: "neha",
        to: "simran",
        msg: "sure, in 10 mins",
        created_at: new Date()
    },
    {
        from: "rohan",
        to: "priya",
        msg: "are you coming to class?",
        created_at: new Date()
    },
    {
        from: "priya",
        to: "rohan",
        msg: "yes, leaving now",
        created_at: new Date()
    }
];
Chat.insertMany(chats);

async function main() {
    await mongoose.connect('mongodb://127.0.0.1:27017/whatsapp');
}