const mongoose = require("mongoose");
const schema = new mongoose.Schema({ 
    from : {
        type : String,
        required: true,
    },
    to : {
        type : String,
        required: true,
    },
    msg : {
        type : String,
        required: true,
        maxLength: 50,
    },
    created_at : {
        type : Date,
        required: true,
    },
});

const Chat = mongoose.model('Chat', schema);
module.exports = Chat;