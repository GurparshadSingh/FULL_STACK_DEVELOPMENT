class Student {
    constructor(id, name, marks) {
        this.id = id
        this.name = name
        this.marks = marks
    }
}

class StudentManager {
    constructor() {
        this.students = [];
    }
    getStudents() {
        return this.students;
    }

    addStudent(id, name, marks) {
        const student = new Student(id, name, marks)
        this.students.push(student)
        console.log("Student added:", student);
    }

    viewStudents() {
        this.students.forEach(s => console.log(s.id, s.name, s.marks))
    }

    deleteStudent(id) {
        this.students = this.students.filter(student => student.id !== Number(id));
        console.log("Student deleted");
    }

    findStudent(search) {
        return this.students.find(s => s.name === search || s.id === Number(search))
    }
    updateMarks(search, newMarks) {
        const st = this.students.find(student => String(student.name) === String(search) || student.id === search)
        if (st) {
            st.marks = newMarks
            console.log(st);
            console.log("marks updated successfully");
        } else {
            console.log("student not found");
        }
    }
    topper() {
        if (this.students.length === 0) return null;
        let topper = this.students[0];

        this.students.forEach(student => {
            if (student.marks > topper.marks) {
                topper = student;
            }
        });
        console.log(student)
    }
}

const manager = new StudentManager();

// manager.addStudent(1, "Alice", 10);
// manager.addStudent(2, "Bob", 20);
// manager.addStudent(3, "Charlie", 30);

// manager.viewStudents();

// manager.updateMarks("Alice", 95);

// console.log("Topper:", manager.getTopper());

// manager.deleteStudent(2);

// manager.viewStudents();
function addStudent() {

    const id = Number(document.getElementById("id").value);
    const name = document.getElementById("name").value;
    const marks = Number(document.getElementById("marks").value);

    manager.addStudent(id, name, marks);

    renderStudents();
}

function renderStudents() {
    const studentList = document.getElementById("studentList");

    studentList.innerHTML = "";

    manager.getStudents().forEach(student => {
        const div = document.createElement("div");
        div.innerHTML = `
            <p>
                ID: ${student.id}
                Name: ${student.name}
                Marks: ${student.marks}
            </p>
        `;
        studentList.appendChild(div);
    });
}