class Student {
    constructor(id, name, marks) {
        this.id = id
        this.name = name
        this.marks = marks
    }
}

class StudentManager {
    constructor() {
        this.students = [];
    }
    getStudents() {
        return this.students;
    }

    addStudent(id, name, marks) {
        const student = new Student(id, name, marks)
        this.students.push(student)
        console.log("Student added:", student);
    }

    viewStudents() {
        this.students.forEach(s => console.log(s.id, s.name, s.marks))
    }

    deleteStudent(id) {
        this.students = this.students.filter(student => student.id !== Number(id));
        console.log("Student deleted");
    }

    updateMarks(search, newMarks) {
        const st = this.students.find(student => String(student.name) === String(search) || student.id === Number(search))
        if (st) {
            st.marks = newMarks
            console.log(st);
            console.log("marks updated successfully");
        } else {
            console.log("student not found");
        }
    }
    topper() {
        if (this.students.length === 0) return null;
        let topper = this.students[0];

        this.students.forEach(student => {
            if (student.marks > topper.marks) {
                topper = student;
            }
        });
        return topper;
    }
}

const manager = new StudentManager();

function addStudent() {

    const id = Number(document.getElementById("id").value);
    const name = document.getElementById("name").value;
    const marks = Number(document.getElementById("marks").value);

    manager.addStudent(id, name, marks);

    renderStudents();
}

function renderStudents() {
    const studentList = document.getElementById("studentList");

    studentList.innerHTML = "";

    manager.getStudents().forEach(student => {
        const div = document.createElement("div");
        div.innerHTML = `
            <p>
                ID: ${student.id}
                Name: ${student.name}
                Marks: ${student.marks}
                </p>
        `;
        studentList.appendChild(div);
    });
}

function findTopper() {
    const ans = document.getElementById("ans");

    // Clear previous result
    ans.innerHTML = "";

    const st = manager.topper();

    if (!st) {
        ans.innerHTML = "<p>No students found!</p>";
        return;
    }

    const top = document.createElement("div");

    top.innerHTML = `
        <p>
            ID: ${st.id}<br>
            Name: ${st.name}<br>
            Marks: ${st.marks}
        </p>
    `;

    ans.appendChild(top);
}


function deleteById() {
    const id = Number(document.getElementById("deleteId").value);
    manager.deleteStudent(id);
    renderStudents();
}


function updateStudentMarks() {
    const search = document.getElementById("searchId").value;
    const marks = document.getElementById("newMarks").value;

    manager.updateMarks(search, marks);
    renderStudents();
}