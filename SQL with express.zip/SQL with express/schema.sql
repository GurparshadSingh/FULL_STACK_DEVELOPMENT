CREATE TABLE user(
    id VARCHAR(50) PRIMARY KEY,
    Username VARCHAR(50) UNIQUE,
    email VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(50) NOT NULL
);

INSERT INTO user (id, Username, email, password)
VALUES (
    'sdfbyugdftyugkvsdf',
    'jdoe',
    'jdoe@example.com',
    'securePassword123'
);