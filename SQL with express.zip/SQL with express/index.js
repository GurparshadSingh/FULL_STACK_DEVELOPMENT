const { faker } = require('@faker-js/faker');
const mysql = require('mysql2');
const express = require("express");
const path = require("path");
const methodOverride = require("method-override");

const app = express();
const port = 8080;

// middleware
app.use(methodOverride("_method"));
app.use(express.urlencoded({ extended: true }));

// ejs setup
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "/views"));

// mysql connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'delta_app',
    password: 'gurparshad0878@#$'
});

// random user generator
let getRandomUser = () => {
    return [
        faker.string.uuid(),
        faker.internet.username(),
        faker.internet.email(),
        faker.internet.password(),
    ];
};

// home route
app.get("/", (req, res) => {

    let q = `SELECT count(*) AS total FROM user`;

    connection.query(q, (err, result) => {

        if (err) {
            console.log(err);
            return res.send("database error");
        }

        let x = result[0].total;

        res.render("home.ejs", { x });
    });
});

// show all users
app.get("/user", (req, res) => {

    let q = `SELECT * FROM user`;

    connection.query(q, (err, users) => {

        if (err) {
            console.log(err);
            return res.send("database error");
        }

        res.render("showusers.ejs", { users });
    });
});

// edit route
app.get("/user/:id/edit", (req, res) => {

    let { id } = req.params;

    let q = `SELECT * FROM user WHERE id = ?`;

    connection.query(q, [id], (err, result) => {

        if (err) {
            console.log(err);
            return res.send("database error");
        }

        let user = result[0];

        res.render("edit.ejs", { user });
    });
});

// update route
app.patch("/user/:id", (req, res) => {

    let { id } = req.params;

    let { username, password } = req.body;

    let q = `SELECT * FROM user WHERE id = ?`;

    connection.query(q, [id], (err, result) => {

        if (err) {
            console.log(err);
            return res.send("database error");
        }

        let user = result[0];

        // password check
        if (password !== user.password) {
            return res.send("Wrong Password!");
        }

        // update username
        let q2 = `UPDATE user SET Username = ? WHERE id = ?`;

        connection.query(q2, [username, id], (err, result) => {

            if (err) {
                console.log(err);
                return res.send("database error");
            }

            res.redirect("/user");
        });
    });
});

// server
app.listen(port, () => {
    console.log(`server listening on port ${port}`);
});